# Mobile-only APK build

1. Create a GitHub repository from your phone.
2. Upload this project files.
3. Open the repository -> Actions.
4. Select "Build Android APK".
5. Tap "Run workflow".
6. When it finishes, open the workflow run and download the artifact named `accord-water-attendance-apk`.
7. The ZIP contains `app-debug.apk`.

Important Firebase setup:
- The project already contains your supplied `google-services.json`.
- Firestore and Storage rules must allow the app's intended authenticated access before production use.
- This starter does not include a secure admin authentication system yet.
