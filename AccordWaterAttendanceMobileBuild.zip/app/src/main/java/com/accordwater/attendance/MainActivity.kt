package com.accordwater.attendance

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    private val db by lazy { FirebaseFirestore.getInstance() }
    private val storage by lazy { FirebaseStorage.getInstance() }
    private val locationClient by lazy { LocationServices.getFusedLocationProviderClient(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { AttendanceApp() } }
    }

    @Composable
    private fun AttendanceApp() {
        var employeeId by remember { mutableStateOf("") }
        var type by remember { mutableStateOf("CHECK_IN") }
        var cameraOpen by remember { mutableStateOf(false) }
        var capture by remember { mutableStateOf<ImageCapture?>(null) }

        val permissionLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { r ->
            if (r[Manifest.permission.CAMERA] == true &&
                r[Manifest.permission.ACCESS_FINE_LOCATION] == true) {
                cameraOpen = true
            }
        }

        if (cameraOpen) {
            CameraScreen(
                onReady = { capture = it },
                onCapture = { capture?.let { takeSelfie(it, employeeId.trim(), type) { cameraOpen=false } } },
                onCancel = { cameraOpen = false }
            )
        } else {
            Column(
                Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("Accord Water", style = MaterialTheme.typography.headlineMedium)
                Text("Employee Selfie Attendance")
                Spacer(Modifier.height(24.dp))
                OutlinedTextField(
                    value = employeeId,
                    onValueChange = { employeeId = it },
                    label = { Text("Employee ID") },
                    singleLine = true
                )
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    FilterChip(
                        selected = type == "CHECK_IN",
                        onClick = { type = "CHECK_IN" },
                        label = { Text("Check In") }
                    )
                    FilterChip(
                        selected = type == "CHECK_OUT",
                        onClick = { type = "CHECK_OUT" },
                        label = { Text("Check Out") }
                    )
                }
                Spacer(Modifier.height(20.dp))
                Button(
                    enabled = employeeId.isNotBlank(),
                    onClick = {
                        permissionLauncher.launch(
                            arrayOf(
                                Manifest.permission.CAMERA,
                                Manifest.permission.ACCESS_FINE_LOCATION
                            )
                        )
                    }
                ) {
                    Text("Take Selfie & Mark Attendance")
                }
            }
        }
    }

    @Composable
    private fun CameraScreen(
        onReady: (ImageCapture) -> Unit,
        onCapture: () -> Unit,
        onCancel: () -> Unit
    ) {
        val context = LocalContext.current
        var view by remember { mutableStateOf<PreviewView?>(null) }

        LaunchedEffect(view) {
            view?.let {
                val provider = ProcessCameraProvider.getInstance(context).get()
                val preview = androidx.camera.core.Preview.Builder().build()
                val imageCapture = ImageCapture.Builder().build()
                preview.setSurfaceProvider(it.surfaceProvider)
                provider.unbindAll()
                provider.bindToLifecycle(
                    this@MainActivity,
                    CameraSelector.DEFAULT_FRONT_CAMERA,
                    preview,
                    imageCapture
                )
                onReady(imageCapture)
            }
        }

        Box(Modifier.fillMaxSize()) {
            AndroidView(
                factory = { PreviewView(context) },
                modifier = Modifier.fillMaxSize(),
                update = { view = it }
            )
            Column(
                Modifier.align(Alignment.BottomCenter).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Button(onClick = onCapture) { Text("CAPTURE SELFIE") }
                TextButton(onClick = onCancel) { Text("Cancel") }
            }
        }
    }

    private fun takeSelfie(
        capture: ImageCapture,
        employeeId: String,
        type: String,
        done: () -> Unit
    ) {
        val file = File(cacheDir, "selfie_${UUID.randomUUID()}.jpg")
        val output = ImageCapture.OutputFileOptions.Builder(file).build()

        capture.takePicture(
            output,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onError(exc: ImageCaptureException) {
                    Toast.makeText(this@MainActivity, "Selfie failed", Toast.LENGTH_LONG).show()
                }
                override fun onImageSaved(result: ImageCapture.OutputFileResults) {
                    saveAttendance(file, employeeId, type, done)
                }
            }
        )
    }

    private fun saveAttendance(
        file: File,
        employeeId: String,
        type: String,
        done: () -> Unit
    ) {
        if (ContextCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            Toast.makeText(this, "Location permission required", Toast.LENGTH_LONG).show()
            return
        }

        locationClient.lastLocation.addOnSuccessListener { loc ->
            val recordId = UUID.randomUUID().toString()
            val stamp = SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss", Locale.getDefault()
            ).format(Date())

            val ref = storage.reference
                .child("attendance_selfies/$employeeId/$recordId.jpg")

            ref.putFile(Uri.fromFile(file))
                .continueWithTask { ref.downloadUrl }
                .addOnSuccessListener { download ->
                    val data = hashMapOf(
                        "employeeId" to employeeId,
                        "type" to type,
                        "timestamp" to stamp,
                        "latitude" to (loc?.latitude ?: 0.0),
                        "longitude" to (loc?.longitude ?: 0.0),
                        "selfieUrl" to download.toString()
                    )

                    db.collection("attendance").document(recordId).set(data)
                        .addOnSuccessListener {
                            Toast.makeText(
                                this,
                                "Attendance marked successfully",
                                Toast.LENGTH_LONG
                            ).show()
                            file.delete()
                            done()
                        }
                        .addOnFailureListener {
                            Toast.makeText(
                                this, "Firebase database error",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                }
                .addOnFailureListener {
                    Toast.makeText(
                        this, "Selfie upload failed",
                        Toast.LENGTH_LONG
                    ).show()
                }
        }
    }
}
